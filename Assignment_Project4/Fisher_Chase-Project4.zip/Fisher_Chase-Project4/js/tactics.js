/*
  Created by Haeshka on 6/24/14.
 */
$('#zebra tr').hover(function() {
    $(this).addClass('hover');
}, function() {
    $(this).removeClass('hover');
});